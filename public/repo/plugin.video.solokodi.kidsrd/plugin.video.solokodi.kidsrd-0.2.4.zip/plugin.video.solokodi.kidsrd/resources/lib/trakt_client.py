import json
import urllib.error
import urllib.parse
import urllib.request

import xbmcaddon

from .constants import HTTP_HEADERS, SETUP_ADDON_ID, TRAKT_API_ROOT


class TraktError(Exception):
    pass


class TraktClient:
    def __init__(self):
        self.addon = xbmcaddon.Addon()
        self._setup = None

    def _setup_addon(self):
        if self._setup is None:
            try:
                self._setup = xbmcaddon.Addon(SETUP_ADDON_ID)
            except RuntimeError:
                self._setup = False
        return self._setup

    def api_token(self):
        setup = self._setup_addon()
        token = setup.getSetting("trakt_api_token") if setup else ""
        token = token or self.addon.getSetting("trakt_api_token")
        if not token:
            raise TraktError("Add your Trakt API token in SoLoKodi Kids Setup.")
        return token

    def has_api_token(self):
        try:
            return bool(self.api_token())
        except TraktError:
            return False

    def _headers(self):
        headers = dict(HTTP_HEADERS)
        headers.update(
            {
                "Content-Type": "application/json",
                "trakt-api-version": "2",
                "trakt-api-key": self.api_token(),
            }
        )
        return headers

    def _request(self, path, params=None):
        query = urllib.parse.urlencode(params or {})
        url = TRAKT_API_ROOT + path
        if query:
            url += "?" + query
        req = urllib.request.Request(url, headers=self._headers())
        try:
            with urllib.request.urlopen(req, timeout=20) as response:
                return json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="ignore")
            raise TraktError("Trakt request failed: HTTP {0}".format(exc.code)) from exc
        except urllib.error.URLError as exc:
            raise TraktError("Could not reach Trakt. Check your internet connection.") from exc
        except (TimeoutError, json.JSONDecodeError) as exc:
            raise TraktError("Trakt request failed: {0}".format(exc)) from exc

    def list_items(self, user, slug, media_type="mixed"):
        path = "/users/{0}/lists/{1}/items".format(
            urllib.parse.quote(user, safe=""),
            urllib.parse.quote(slug, safe=""),
        )
        payload = self._request(path, {"extended": "full"})
        items = []
        for row in payload or []:
            item_type = row.get("type")
            if item_type == "movie":
                media = "movie"
                data = row.get("movie") or {}
            elif item_type == "show":
                media = "show"
                data = row.get("show") or {}
            else:
                continue
            if media_type in ("movie", "show") and media != media_type:
                continue
            ids = data.get("ids") or {}
            tmdb_id = ids.get("tmdb")
            if not tmdb_id:
                continue
            items.append(
                {
                    "media_type": media,
                    "tmdb_id": tmdb_id,
                    "title": data.get("title") or "Untitled",
                    "year": data.get("year"),
                    "overview": data.get("overview") or "",
                }
            )
        return items
