import json
import time
import urllib.error
import urllib.parse
import urllib.request

import xbmc
import xbmcaddon
import xbmcgui

from . import wizard

ADDON = xbmcaddon.Addon()
CLIENT_ID = "X245A4XAIBGVM"
DEVICE_URL = "https://api.real-debrid.com/oauth/v2/device/code"
CREDENTIALS_URL = "https://api.real-debrid.com/oauth/v2/device/credentials"
TOKEN_URL = "https://api.real-debrid.com/oauth/v2/token"
API_ROOT = "https://api.real-debrid.com/rest/1.0"

TRAKT_CLIENT_ID = "c55e97fb5825a07c39050d2bc4a8996e8d19356cb6d22efdf3f3edb9bd93ef53"
TRAKT_DEVICE_URL = "https://api.trakt.tv/oauth/device/code"
TRAKT_TOKEN_URL = "https://api.trakt.tv/oauth/device/token"
USER_AGENT = "SoLoKodi/1.1.0 (Kodi Build)"


def notify(message, heading="SoLoKodi Kids"):
    xbmcgui.Dialog().notification(heading, message, xbmcgui.NOTIFICATION_INFO, 5000)


def request_json(url, data=None, headers=None, method=None):
    req_headers = {"User-Agent": USER_AGENT}
    if headers:
        req_headers.update(headers)

    body = None
    if data is not None:
        if headers and headers.get("Content-Type") == "application/json":
            body = json.dumps(data).encode("utf-8")
        else:
            body = urllib.parse.urlencode(data).encode("utf-8")

    req = urllib.request.Request(url, data=body, headers=req_headers, method=method)
    with urllib.request.urlopen(req, timeout=20) as response:
        raw = response.read().decode("utf-8")
    return json.loads(raw) if raw else {}


def run_kids_setup():
    wizard.run_setup_wizard()


def run_family_setup():
    run_kids_setup()


def show_parent_tips():
    xbmcgui.Dialog().textviewer(
        "Parent Tips (Optional)",
        "\n".join(
            [
                "SoLoKodi Kids is built for fun — no restrictions on kid content sources.",
                "",
                "Optional ideas if you share this device with adults:",
                "1. Create a separate Kids profile in Kodi.",
                "2. Use Master Lock if you want to hide settings from little hands.",
                "3. Real-Debrid and Trakt power streaming and sync.",
                "",
                "Use Setup Wizard anytime to repair shortcuts or finish optional steps.",
            ]
        ),
    )


def show_lock_checklist():
    show_parent_tips()


def poll_for_credentials(device_code, interval, expires_in):
    deadline = time.time() + min(int(expires_in), 1800)
    progress = xbmcgui.DialogProgress()
    progress.create("Real-Debrid", "Waiting for authorization...")

    while time.time() < deadline and not progress.iscanceled():
        remaining = int(deadline - time.time())
        progress.update(max(0, min(99, 100 - int((remaining / int(expires_in)) * 100))))
        try:
            credentials = request_json(
                CREDENTIALS_URL
                + "?"
                + urllib.parse.urlencode({"client_id": CLIENT_ID, "code": device_code})
            )
            progress.close()
            return credentials
        except urllib.error.HTTPError:
            xbmc.sleep(int(interval) * 1000)
    progress.close()
    return None


def connect_real_debrid():
    ok = xbmcgui.Dialog().yesno(
        "Connect Real-Debrid",
        "Authorize Real-Debrid for this Kodi profile. Tokens stay local on this device. Continue?",
    )
    if not ok:
        return

    auth = request_json(DEVICE_URL + "?" + urllib.parse.urlencode({"client_id": CLIENT_ID, "new_credentials": "yes"}))
    xbmcgui.Dialog().ok(
        "Real-Debrid Device Code",
        "Go to: {0}\nEnter code: {1}".format(auth["verification_url"], auth["user_code"]),
    )

    credentials = poll_for_credentials(auth["device_code"], auth.get("interval", 5), auth.get("expires_in", 1800))
    if not credentials:
        xbmcgui.Dialog().ok("Real-Debrid", "Authorization timed out or was cancelled.")
        return

    token = request_json(
        TOKEN_URL,
        {
            "client_id": credentials["client_id"],
            "client_secret": credentials["client_secret"],
            "code": auth["device_code"],
            "grant_type": "http://oauth.net/grant_type/device/1.0",
        },
    )
    expires_at = str(int(time.time()) + int(token.get("expires_in", 0)))

    ADDON.setSetting("rd_client_id", credentials["client_id"])
    ADDON.setSetting("rd_client_secret", credentials["client_secret"])
    ADDON.setSetting("rd_access_token", token.get("access_token", ""))
    ADDON.setSetting("rd_refresh_token", token.get("refresh_token", ""))
    ADDON.setSetting("rd_expires_at", expires_at)
    notify("Real-Debrid connected")


def auth_headers():
    token = ADDON.getSetting("rd_access_token")
    if not token:
        return None
    return {"Authorization": "Bearer " + token}


def check_real_debrid():
    headers = auth_headers()
    if not headers:
        xbmcgui.Dialog().ok("Real-Debrid", "No Real-Debrid authorization is saved in this Kodi profile.")
        return
    try:
        user = request_json(API_ROOT + "/user", headers=headers)
    except urllib.error.HTTPError as exc:
        xbmcgui.Dialog().ok("Real-Debrid", "Authorization check failed: HTTP {0}".format(exc.code))
        return
    xbmcgui.Dialog().ok(
        "Real-Debrid Connected",
        "User: {0}\nType: {1}\nPremium seconds remaining: {2}".format(
            user.get("username", "unknown"),
            user.get("type", "unknown"),
            user.get("premium", "unknown"),
        ),
    )


def clear_real_debrid():
    if not xbmcgui.Dialog().yesno("Real-Debrid", "Remove saved Real-Debrid credentials from this Kodi profile?"):
        return
    for key in ("rd_client_id", "rd_client_secret", "rd_access_token", "rd_refresh_token", "rd_expires_at"):
        ADDON.setSetting(key, "")
    notify("Real-Debrid authorization cleared")


def connect_trakt():
    ok = xbmcgui.Dialog().yesno(
        "Connect Trakt",
        "Authorize Trakt.tv to sync your watchlist and collection with SoLoKodi. Continue?",
    )
    if not ok:
        return False

    try:
        auth = request_json(
            TRAKT_DEVICE_URL,
            data={"client_id": TRAKT_CLIENT_ID},
            headers={
                "Content-Type": "application/json",
                "trakt-api-version": "2",
                "trakt-api-key": TRAKT_CLIENT_ID,
            },
            method="POST",
        )
    except Exception as exc:
        xbmcgui.Dialog().ok("Trakt Setup", "Failed to initiate Trakt authorization: {0}".format(exc))
        return False

    verification_url = auth.get("verification_url") or "https://trakt.tv/activate"
    user_code = auth.get("user_code", "")
    device_code = auth.get("device_code", "")
    interval = auth.get("interval", 5)
    expires_in = auth.get("expires_in", 600)

    xbmcgui.Dialog().ok(
        "Trakt Device Code",
        "Go to: {0}\nEnter code: {1}".format(verification_url, user_code),
    )

    deadline = time.time() + min(int(expires_in), 600)
    progress = xbmcgui.DialogProgress()
    progress.create("Trakt Authorization", "Waiting for code entry on Trakt...")

    token = None
    while time.time() < deadline and not progress.iscanceled():
        remaining = int(deadline - time.time())
        progress.update(max(0, min(99, 100 - int((remaining / int(expires_in)) * 100))))
        try:
            res = request_json(
                TRAKT_TOKEN_URL,
                data={
                    "code": device_code,
                    "client_id": TRAKT_CLIENT_ID,
                },
                headers={
                    "Content-Type": "application/json",
                    "trakt-api-version": "2",
                    "trakt-api-key": TRAKT_CLIENT_ID,
                },
                method="POST",
            )
            if res and res.get("access_token"):
                token = res
                break
        except urllib.error.HTTPError as exc:
            if exc.code == 400:
                xbmc.sleep(int(interval) * 1000)
            else:
                break
        except Exception:
            xbmc.sleep(int(interval) * 1000)

    progress.close()
    if not token:
        xbmcgui.Dialog().ok("Trakt Setup", "Authorization timed out or was cancelled.")
        return False

    ADDON.setSetting("trakt_access_token", token.get("access_token", ""))
    ADDON.setSetting("trakt_refresh_token", token.get("refresh_token", ""))
    notify("Trakt connected")
    return True


def check_trakt():
    token = ADDON.getSetting("trakt_access_token")
    if not token:
        xbmcgui.Dialog().ok("Trakt", "No Trakt authorization is saved in this Kodi profile.")
        return
    xbmcgui.Dialog().ok("Trakt Connected", "Trakt authorization is active in this profile.")


def clear_trakt():
    if not xbmcgui.Dialog().yesno("Trakt", "Remove saved Trakt credentials from this profile?"):
        return
    ADDON.setSetting("trakt_access_token", "")
    ADDON.setSetting("trakt_refresh_token", "")
    notify("Trakt authorization cleared")
